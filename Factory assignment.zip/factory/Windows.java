package factory;

public class Windows implements OS{

    @Override
    public void printMobile() {
        System.out.println("very most bad");
    }
}
