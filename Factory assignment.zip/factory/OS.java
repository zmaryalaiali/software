package factory;

public interface OS {
    void printMobile();
}
