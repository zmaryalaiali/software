package factory;

public class IOS implements OS{
    @Override
    public void printMobile() {
        System.out.println("very most secure ");
    }
}
