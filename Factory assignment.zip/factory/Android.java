package factory;

public class Android implements OS{
    @Override
    public void printMobile() {
        System.out.println("very most power ful and secure");
    }
}
